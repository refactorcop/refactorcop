# encoding: utf-8

class Procto < Module
  # Gem version
  VERSION = '0.0.3'.freeze
end
